package com.vaibhav.saasforge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaasforgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaasforgeApplication.class, args);
	}

}
